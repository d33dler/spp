from .encoders.encoder import Encoder

__all__ = {
    'DefaultDual': Encoder
}

