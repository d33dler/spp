
class CatBoostHead:
    def __init__(self) -> None:
        super().__init__()