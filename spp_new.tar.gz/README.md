# spp
Short programming project Few-shot learning
